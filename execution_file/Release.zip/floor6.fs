#version 330 core

in vec3 ObjNormal;
in vec3 FragPos;

out vec4 ObjColor;

uniform vec3 vPos;

void main()
{
   vec3 lightPos = vec3(150.0f, 600.0f, -100.0f);
   vec3 lightColor = vec3(1.0f, 1.0f, 1.0f);
	vec3 objectColor = vec3(1.0f, 1.0f, 1.0f);
   vec3 lightDir = normalize(lightPos - FragPos);
   
   //ambient
   float ambientStrength = 0.3f;
   vec3 ambient = ambientStrength * lightColor;

   //diffuse
   vec3 norm = normalize(ObjNormal);
   float diff = max(dot(norm, lightDir), 0.0f);
   vec3 diffuse = diff * lightColor;

   //specular
   float specularStrength = 0.1f;
   vec3 viewDir = normalize(vPos - FragPos);
   vec3 reflectDir = reflect(-lightDir, norm);
   float spec = pow(max(dot(viewDir, reflectDir), 0.0f), 128);
   vec3 specular = specularStrength * spec * lightColor;
  
   vec3 result = (ambient + diffuse + specular) * objectColor;
   ObjColor = vec4(result, 1.0f);
}
